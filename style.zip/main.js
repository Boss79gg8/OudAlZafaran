document.addEventListener("DOMContentLoaded", function() {
  // إخفاء شاشة الإنترو بعد 3 ثوانٍ
  window.addEventListener("load", function() {
    const preloader = document.getElementById("preloader");
    setTimeout(() => {
      preloader.style.opacity = "0";
      preloader.style.visibility = "hidden";
    }, 3000);
  });

  // فلترة المنتجات باستخدام مربع البحث
  const searchInput = document.getElementById("searchInput");
  const productsGrid = document.getElementById("productsList");
  const productBoxes = Array.from(productsGrid.getElementsByClassName("product-box"));
  searchInput.addEventListener("input", function() {
    const filter = this.value.trim().toLowerCase();
    productBoxes.forEach(box => {
      const text = box.textContent.toLowerCase();
      box.style.display = text.includes(filter) ? "block" : "none";
    });
  });

  // فتح وإغلاق نافذة المودال لتفاصيل المنتج
  const modal = document.getElementById("productModal");
  const modalClose = document.getElementById("modalClose");
  const modalProductName = document.getElementById("modalProductName");
  productBoxes.forEach(box => {
    box.addEventListener("click", function() {
      const productName = box.getAttribute("data-product");
      modalProductName.textContent = productName;
      modal.style.display = "block";
    });
  });
  if (modalClose) {
    modalClose.addEventListener("click", () => { modal.style.display = "none"; });
  }
  window.addEventListener("click", e => {
    if (e.target === modal) { modal.style.display = "none"; }
  });

  // زر الصعود للأعلى
  const scrollToTopBtn = document.getElementById("scrollToTop");
  scrollToTopBtn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  // تحديث شريط تقدم التمرير وتأثير Parallax لدوائر الخلفية
  const scrollProgress = document.getElementById("scrollProgress");
  window.addEventListener("scroll", function() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    scrollProgress.style.width = ((scrollTop / scrollHeight) * 100) + "%";
    document.querySelectorAll(".red-circle").forEach(circle => {
      circle.style.transform = `translateY(${scrollTop * 0.2}px)`;
    });
  });

  // ظهور العناصر عند التمرير باستخدام Intersection Observer
  const animatedElements = document.querySelectorAll(".animate");
  const observerOptions = { threshold: 0.2 };
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        obs.unobserve(entry.target);
      }
    });
  }, observerOptions);
  animatedElements.forEach(el => observer.observe(el));

  // تحديث السنة في الفوتر
  const currentYearSpan = document.getElementById("currentYear");
  currentYearSpan.textContent = new Date().getFullYear();

  // انتقال سلس عند النقر على روابط القائمة
  const navLinks = document.querySelectorAll(".nav-links a");
  navLinks.forEach(link => {
    link.addEventListener("click", function(e) {
      e.preventDefault();
      const targetId = this.getAttribute("href");
      const targetSection = document.querySelector(targetId);
      if (targetSection) {
        targetSection.scrollIntoView({ behavior: "smooth" });
      }
      navLinks.forEach(l => l.classList.remove("active-link"));
      this.classList.add("active-link");
    });
  });

  // شريط آراء الزبائن (Testimonials Slider) تلقائي
  const testimonialsSlider = document.querySelector(".testimonials-slider");
  if (testimonialsSlider) {
    let sliderIndex = 0;
    const slides = testimonialsSlider.querySelectorAll(".testimonial-slide");
    const totalSlides = slides.length;
    setInterval(() => {
      sliderIndex = (sliderIndex + 1) % totalSlides;
      testimonialsSlider.scrollTo({
        left: sliderIndex * (slides[0].offsetWidth + 16),
        behavior: "smooth"
      });
    }, 5000);
  }
});
